//#include <iostream>
//#include <string>
//#include <cstring>
//
//
//using namespace std;
//
//
//int slen(string st);
//int finds(string st, string find );
//void replace(string st, string find, string rep);
//
//
//int main()
//{
//	
//	string od;
//	string replace1;
//	string find;
//
//	cout << "Entre the original string : ";
//	getline (cin,od);
//	cout << "THe length : " << slen(od);
//	cout << "Entre The string you want to find : ";
//	getline(cin,find);
//	
//	if (finds(od, find) != -1)
//	{
//		cout << "\n The string you entered exists in the original string.\n";
//		cout << "Entre the string you want to replace with the string you find : ";
//		getline (cin,replace1);
//		cout << "\nThe original string was : " << od;
//		replace(od, find, replace1);
//		cout << "\n After replacing original string becomes : " << od;
//	}
//	else
//	{
//		cout << "\nThe entered string doesnot exists in the original string.\n";
//	}
//
//	
//	return 0;
//}
//int slen(string st)
//{
//	int i;
//	for ( i = 0; st[i] != '\0'; ++i);
//	return i;
//}
//int finds(string st, string find)
//{
//
//	int j = 0;
//	int l;
//	int k, i;
//	bool f = false;
//	for (i = 0; i < 100; ++i)
//	{
//		if (st[i] == find[0])
//		{
//			l = i;
//			k = 0;
//			for (j = 0; j < slen(find); ++j, ++l)
//			{
//				if (st[l] == find[j])
//				{
//					++k;
//				}
//
//			}
//			if (k == slen(find))
//			{
//				f = true;
//				return i;
//			}
//
//		}
//	}
//	if (!f)
//		return -1;
//}
//void replace(string st, string find, string rep)
//{
//	int i = finds(st, find);
//	if (slen(find) == slen(rep))
//	{
//		int a = slen(rep);
//		int y = 0;
//		for (int x = 0; x < 100; ++x)
//		{
//
//			if (x == i)
//			{
//				for (int z = x; z < x + slen(rep); ++z)
//				{
//					st[z] = rep[y];
//					++y;
//				}
//			}
//		}
//	}
//	else if (slen(find) > slen(rep))
//	{
//		int a = slen(find) - slen(rep);
//		int b = finds(st,find) + slen(find);
//		int c = finds(st, find) + slen(rep);
//		for (int i = b; st[i] != '\0'; ++i)
//		{
//			st[c] = st[i];
//			
//			++c;
//		}
//		
//		st[c] = '\0';
//		int y = 0;
//		for (int x = i; x < slen(rep) + i; ++x)
//		{
//			st[x] = rep[y];
//			++y;
//		}
//	}
//	else if (slen(find) < slen(rep))
//	{
//		int a = slen(rep) - slen(find);
//		int b = a + slen(st);
//		int c = slen(st);
//		for (int x = b; x>=finds(st,find)+slen(rep); --x)
//		{
//			st[x] = st[c];
//			--c;
//		}
//		st[b] = '\0';
//		int y = 0;
//		for (int x = i; x < slen(rep) + i; ++x)
//		{
//			st[x] = rep[y];
//			++y;
//		}
//	}
//}
