#include <iostream>
#include <iomanip>
using namespace std;
void display(char td[][3]);
int main()
{
	char td[3][3] = { { '*','*' ,'*' },{'*','*','*'},{'*','*','*'} };
	cout << "Welcome to 'TIK TAK TOE' game.\n\n"
		<< "Prove Yourself a champ by winnig it and prove that you are not a loser by default \n\n"
		<< "Note down the rules. ";
	cout << "\n\nYou have to place (X for Player 1 and O for player 2) on an entire row or a column or a diagnol and make a straight line\n\n\n"
		<< "One who owns a staright line first wins the game \n\n";
	int r1, c1, r2, c2,x;
	cout << "\n\nIf you want to start a new game entre 1 otherwise any number\n\n";
	cin >> x;
	if (x == 1)
	{
		do
		{
			cout << "At any instance, if you want to end the game entre row or column greater than or equal to 4.\n\n";
				

			system("CLS");
			display(td);
			cout << "\n\nIts the turn of Player 1\n\n";

			
			
			cout << "\n\nEntre the row number of desired place : ";
			cin >> r1;
			cout << "\nEntre the column number of desired place : ";
			cin >> c1;
			
			while (td[r1-1][c1-1] != '*')
			{
				if (td[r1 - 1][c1 - 1] == 'X')
				{
					cout << "\nThis place is already taken by you (Player 1). \n";
				}
				else if (td[r1 - 1][c1 - 1] == 'O')
				{
					cout << "\nThis place is already taken by your opponent.\n";
				}
				cout << "\n\nEntre the row number of desired place : ";
				cin >> r1;
				cout << "\nEntre the column number of desired place : ";
				cin >> c1;
			}

			td[r1 - 1][c1 - 1] = 'X';
			bool  f = false;
			
			
			for (int i = 0; i < 3; ++i)
			{
				for (int j = 0; j < 3; ++j)
				{
					if (td[i][j] == '*')
					{
						f = true;
						break;
					}
				}
				if (f)
				{
					break;
				}
			}
			system("CLS");
			display(td);
			if (!f)
			{
				cout << "As all the boxes are taken so its a tie.\n\n";
				break;
			}
			
			int h, d;
			
			for (int e = 0; e < 3; ++e)
			{
				d = 0;
				for (h = 0; h < 3; ++h)
				{

					if (td[e][h] == 'X')
					{
						++d;
					}
					if (d == 3)
					{
						cout << "Player 1 wins it \n\n";
						cout << "Player 2 loses\n\n";
						break;
					}
				}
				if (d == 3)
					break;
				
			}
			if (d == 3)
				break;
			for (int e = 0; e < 3; ++e)
			{
				d = 0;
				for (h = 0; h < 3; ++h)
				{

					if (td[h][e] == 'X')
					{
						++d;
					}
					if (d == 3)
					{
						cout << "\nPlayer 1 wins it\n\n";
						cout << "\nPlayer 2 loses\n\n";
						break;
					}
				}
				if (d == 3)
					break;
				
			}
			if (d == 3)
				break;
			d = 0;
			for (int e = 0; e < 3; ++e)
			{
				
				for (h = 0; h < 3; ++h)
				{
					if (e == h)
					{
						if (td[h][e] == 'X')
						{
							++d;
						}
					}

					
					if (d == 3)
					{
						cout << "Player 1 wins it.\n\n";
						cout << "Player 2 loses\n\n";
						break;
					}
				}
				if (d == 3)
					break;
				
			}
			if (d == 3)
				break;
			d = 0;
			for (int e = 0; e < 3; ++e)
			{
				
				for (h = 0; h < 3; ++h)
				{
					if ( e + h == 2  )
					{
						if (td[h][e] == 'X')
						{
							++d;
						}
					}


					if (d == 3)
					{
						cout << "Player 1 wins it\n\n";
						cout << "Player 2 loses\n\n";
						break;
					}
				}
				if (d == 3)
					break;

			}
			if (d == 3)
				break;
			

			

			

			

			cout << "\n\nIts the turn of Player 2\n\n";

			cout << "\n\nEntre the row number of desired place : ";
			cin >> r1;
			cout << "\nEntre the column number of desired place : ";
			cin >> c1;

			while (td[r1 - 1][c1 - 1] != '*')
			{
				if (td[r1 - 1][c1 - 1] == 'O')
				{
					cout << "\nThis place is already taken by you (Player 2). \n";
				}
				else if (td[r1 - 1][c1 - 1] == 'X')
				{
					cout << "\nThis place is already taken by your opponent .\n";
				}
				cout << "\n\nEntre the row number of desired place : ";
				cin >> r1;
				cout << "\nEntre the column number of desired place : ";
				cin >> c1;
			}

			td[r1 - 1][c1 - 1] = 'O';
			system("CLS");
			display(td);

			

			if (!f)
			{
				cout << "As all the boxes are taken so its a tie.\n\n";
				break;
			}
			for (int e = 0; e < 3; ++e)
			{
				d = 0;
				for (h = 0; h < 3; ++h)
				{

					if (td[e][h] == 'X')
					{
						++d;
					}
					if (d == 3)
					{
						cout << "Player 2 wins it \n\n";
						cout << "Player 1 loses\n\n";
						break;
					}
				}
				if (d == 3)
					break;

			}
			if (d == 3)
				break;
			for (int e = 0; e < 3; ++e)
			{
				d = 0;
				for (h = 0; h < 3; ++h)
				{

					if (td[h][e] == 'X')
					{
						++d;
					}
					if (d == 3)
					{
						cout << "\nPlayer 2 wins it\n\n";
						cout << "\nPlayer 1 loses\n\n";
						break;
					}
				}
				if (d == 3)
					break;

			}
			if (d == 3)
				break;
			d = 0;
			for (int e = 0; e < 3; ++e)
			{
				
				for (h = 0; h < 3; ++h)
				{
					if (e == h)
					{
						if (td[h][e] == 'X')
						{
							++d;
						}
					}


					if (d == 3)
					{
						cout << "Player 2 wins it\n\n";
						cout << "Player 1 loses\n\n";
						break;
					}
				}
				if (d == 3)
					break;

			}
			if (d == 3)
				break;
			d = 0;
			for (int e = 0; e < 3; ++e)
			{
				
				for (h = 0; h < 3; ++h)
				{
					if (e + h == 2)
					{
						if (td[h][e] == 'X')
						{
							++d;
						}
					}


					if (d == 3)
					{
						cout << "Player 2 wins it.\n\n";
						cout << "Player 1 loses\n\n";
						break;
					}
				}
				if (d == 3)
					break;

			}
			if (d == 3)
				break;

			





			
			

			



			if (c1 > 3  || r1 > 3 )
			{
				cout << "\n\nYou ended the game by entering number 4 or greater than that\n\n";
				break;
			}

		} 
		while (c1 <= 3 ||  r1 <= 2 );
		
	}
	else
	{
		cout << "\n\nYou quitted the game\n\n";
	}

	
	return 0;



}
void display(char td[][3])
{
	cout << endl <<setw(69)<< "_____________________________" << endl;

	for (int i = 0; i < 3; ++i)
	{
		cout <<setw(70)<<"|         |         |         |" << endl;
		cout << "                                       |";
		for (int j = 0; j < 3; ++j)
		{
			cout << setw(5) << td[i][j] << setw(5) << "|";
		}
		cout <<endl<<setw(70)<< "|_________|_________|_________|" << endl;
	}
}